#ifndef SQL_HPP
#define SQL_HPP

class SQL
{
	public:
		void ins();
		void del();
		void update();
		void find();	
};

#endif
