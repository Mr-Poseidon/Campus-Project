#include<iostream>

#include "Pets.hpp"
#include "PowerPets.hpp" 
#include "DefencePets.hpp" 
#include "MeatPets.hpp" 
#include "QuickPets.hpp" 


using namespace std;

int main()
{
//	DefencePets pp;
//	PowerPets pp;
//	MeatPets pp; 
//	QuickPets pp; 

	pp.DataShow(); 
	
	pp.AddExperience();//����
	pp.DataShow();//����չʾ 
	 
	for(int i=0;i<2;i++)//����
		pp.AddExperience();
	pp.DataShow();//����չʾ 
	
	return 0;
}
