#include "Server.hpp"
#include "Client.hpp"

int main(){
    
	Server server;
	server.Start();
	
    return 0;
}
