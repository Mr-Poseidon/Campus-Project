#ifndef MAINWINDOW_LOGIN_AND_REGIESTER_H
#define MAINWINDOW_LOGIN_AND_REGIESTER_H

#include <QMainWindow>

#include "ClientSources/Client.hpp"


namespace Ui {
class MainWindow_login_and_regiester;
}

class MainWindow_login_and_regiester : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow_login_and_regiester(QWidget *parent = nullptr);
    ~MainWindow_login_and_regiester();

private slots:
    void on_leUsername_textEdited(const QString &arg1);

    void on_lePassword_textEdited(const QString &arg1);

    void on_pbtnLogin_clicked();

    void on_leUsername_2_textEdited(const QString &arg1);

    void on_lePassword_2_textEdited(const QString &arg1);

    void on_lePassword_3_textEdited(const QString &arg1);

    void on_pbtnRegister_clicked();

private:
    Ui::MainWindow_login_and_regiester *ui;
    Client clnt;


    signals:
        void Login(Account);
};

#endif // MAINWINDOW_LOGIN_AND_REGIESTER_H
