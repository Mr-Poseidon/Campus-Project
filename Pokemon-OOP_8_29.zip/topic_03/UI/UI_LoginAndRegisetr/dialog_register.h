#ifndef DIALOG_REGISTER_H
#define DIALOG_REGISTER_H

#include <QDialog>

namespace Ui {
class Dialog_register;
}

class Dialog_register : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_register(QWidget *parent = nullptr);
    ~Dialog_register();

private:
    Ui::Dialog_register *ui;
};

#endif // DIALOG_REGISTER_H
