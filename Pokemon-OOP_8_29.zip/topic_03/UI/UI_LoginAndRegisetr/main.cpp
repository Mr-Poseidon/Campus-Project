#include "mainwindow_login_and_regiester.h"
#include "mainwindow_game.h"
#include "dialog_register.h"
#include <QApplication>
#include <QObject>

#include "ClientSources/Client.hpp"
#include "ClientSources/Account.hpp"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow_login_and_regiester winLogin;
    MainWindow_game winGame;

    QObject::connect(&winLogin,SIGNAL(Login(Account)),&winGame,SLOT(startGame(Account)));

    winLogin.show();


//    MainWindow_game g;
//    g.show();




    return a.exec();
}
