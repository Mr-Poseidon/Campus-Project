#include "mainwindow_game.h"
#include "ui_mainwindow_game.h"

#include<QStandardItemModel>
#include<QStandardItem>
#include<vector>
#include<string>

#include "ClientSources/Client.hpp"
#include "ClientSources/PetsClass/Pets.hpp"

MainWindow_game::MainWindow_game(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow_game)
{
    ui->setupUi(this);
    this->clnt= new Client;//实例化clnt对象
}

MainWindow_game::~MainWindow_game()
{
    delete ui;
}



void MainWindow_game::PetsListModel()//获取精灵列表模型，便于设置tableView
{
    QStandardItemModel* model = new QStandardItemModel();

    this->ui->tbvMyPetsBag->setModel(model);//显示精灵列表

    model->setColumnCount(8);
    model->setHeaderData(0,Qt::Horizontal,"名称");
    model->setHeaderData(1,Qt::Horizontal,"等级");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"攻击");
    model->setHeaderData(4,Qt::Horizontal,"防御");
    model->setHeaderData(5,Qt::Horizontal,"生命");
    model->setHeaderData(6,Qt::Horizontal,"敏捷");
    model->setHeaderData(7,Qt::Horizontal,"经验值");

    vector<Pets> li=this->clnt->AccountPetsList(this->ac.username);//获取精灵列表
    int i=0;
    for(vector<Pets>::iterator it=li.begin();it!=li.end();it++)
    {
        model->setItem(i,0,new QStandardItem(QString(it->GetName())));

        model->setItem(i,1,new QStandardItem(QString::number(it->GetLevel())));

        int tp=0;
        tp+=it->GetType();
        if(tp==0){
            model->setItem(i,2,new QStandardItem("普通"));
        }else if(tp==1){
            model->setItem(i,2,new QStandardItem("攻击型"));
        }else if(tp==2){
            model->setItem(i,2,new QStandardItem("防御型"));
        }else if(tp==3){
            model->setItem(i,2,new QStandardItem("肉盾型"));
        }else if(tp==4){
            model->setItem(i,2,new QStandardItem("敏捷型"));
        }

        model->setItem(i,3,new QStandardItem(QString::number((long)it->GetAggressivity())));
        model->setItem(i,4,new QStandardItem(QString::number((long)it->GetDefence())));
        model->setItem(i,5,new QStandardItem(QString::number((long)it->GetLife())));

        model->setItem(i,6,new QStandardItem(QString::number(it->GetAttackInterval(),'f',2)));//设置敏捷值

        QString str=QString::number((long)it->GetExperience(),10)+"/"+QString::number((long)it->GetExperienceNeed(),10);//构造经验值字符串，例如：1/2
        model->setItem(i,7,new QStandardItem(str));

        i++;
    }

}

void MainWindow_game::OnlineUserListModel()
{
    QStandardItemModel *model = new QStandardItemModel();
    this->ui->tbvOnlineUserList->setModel(model);

    model->setColumnCount(2);
    model->setHeaderData(0,Qt::Horizontal,"用户名");
    model->setHeaderData(1,Qt::Horizontal,"查看详情");

    vector<Account> li=this->clnt->OnlineUserList();//获取在线用户列表
    int i=0;
    for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
    {
        model->setItem(i,0,new QStandardItem(QString(it->username)));
        model->setItem(i,1,new QStandardItem("双击查看详情"));

        i++;
    }

}

void MainWindow_game::RegisterUserListModel()
{
    QStandardItemModel *model = new QStandardItemModel();
    this->ui->tbvRegisterUserList->setModel(model);

    model->setColumnCount(2);
    model->setHeaderData(0,Qt::Horizontal,"用户名");
    model->setHeaderData(1,Qt::Horizontal,"查看详情");

    vector<Account> li=this->clnt->AllRegisterUserList();//获取所有用户列表
    int i=0;
    for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
    {
        model->setItem(i,0,new QStandardItem(QString(it->username)));
        model->setItem(i,1,new QStandardItem("双击查看详情"));

        i++;
    }



}

void MainWindow_game::on_tabWidget_PetsBag_tabBarClicked(int index)
{
    if(index==0){
        PetsListModel();
    }
    else if(index==1){
        OnlineUserListModel();
    }
    else if(index==2){
        RegisterUserListModel();
    }

}

void MainWindow_game::startGame(Account ac)//登陆游戏后的初始化操作
{
    this->ac=ac;//记录账户

    this->clnt->Login(this->ac.username,this->ac.password);

    this->ui->leUsername->setText(QString::fromLocal8Bit(this->ac.username));//设置用户名



    vector<Pets> li=this->clnt->AccountPetsList(this->ac.username);//获取自己的精灵列表;
    this->ui->lePetsCount->setText(QString::number(li.size(),10));//设置精灵数量

    PetsListModel();//显示精灵列表
//    OnlineUserListModel();
//    RegisterUserListModel();

    //设置选中时为整行选中
    this->ui->tbvMyPetsBag->setSelectionBehavior(QAbstractItemView::SelectRows);
    this->ui->tbvOnlineUserList->setSelectionBehavior(QAbstractItemView::SelectRows);
    this->ui->tbvRegisterUserList->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设置表格的单元为只读属性，即不能编辑
    this->ui->tbvMyPetsBag->setEditTriggers(QAbstractItemView::NoEditTriggers);
    this->ui->tbvOnlineUserList->setEditTriggers(QAbstractItemView::NoEditTriggers);
    this->ui->tbvRegisterUserList->setEditTriggers(QAbstractItemView::NoEditTriggers);

    this->show();//显示窗口
}
