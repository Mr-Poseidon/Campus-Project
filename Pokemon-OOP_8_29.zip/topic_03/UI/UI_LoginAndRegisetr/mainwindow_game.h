#ifndef MAINWINDOW_GAME_H
#define MAINWINDOW_GAME_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QStandardItem>


#include "ClientSources/Account.hpp"
#include "ClientSources/Client.hpp"


namespace Ui {
class MainWindow_game;
}

class MainWindow_game : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow_game(QWidget *parent = nullptr);
    ~MainWindow_game();

    void PetsListModel();
    void OnlineUserListModel();
    void RegisterUserListModel();

private slots:
    void on_tabWidget_PetsBag_tabBarClicked(int index);

    void startGame(Account ac);



private:
    Ui::MainWindow_game *ui;
    Client *clnt;
    Account ac;
};

#endif // MAINWINDOW_GAME_H
