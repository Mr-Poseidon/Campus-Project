#include "dialog_register.h"
#include "ui_dialog_register.h"

Dialog_register::Dialog_register(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_register)
{
    ui->setupUi(this);
}

Dialog_register::~Dialog_register()
{
    delete ui;
}
