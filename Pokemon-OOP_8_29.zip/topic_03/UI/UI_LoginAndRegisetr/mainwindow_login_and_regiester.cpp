#include "mainwindow_login_and_regiester.h"
#include "ui_mainwindow_login_and_regiester.h"
#include "dialog_register.h"

#include<QString>
#include<QMessageBox>

MainWindow_login_and_regiester::MainWindow_login_and_regiester(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow_login_and_regiester)
{
    ui->setupUi(this);

}

MainWindow_login_and_regiester::~MainWindow_login_and_regiester()
{
    delete ui;
}

void MainWindow_login_and_regiester::on_leUsername_textEdited(const QString &arg1)
{
    QByteArray ba=arg1.toLatin1();
    if(this->clnt.isUsernameExit(ba.data())){
        this->ui->login_tip->setText("");
    }else{
        this->ui->login_tip->setText("用户名不存在");
    }
}

void MainWindow_login_and_regiester::on_lePassword_textEdited(const QString &arg1)
{
    if(arg1.toLocal8Bit().length()<6){
        this->ui->login_tip->setText("密码过短");
    }else if(arg1.toLocal8Bit().length()>18){
        this->ui->login_tip->setText("密码过长");
    }else{
        this->ui->login_tip->setText("");
    }
}

void MainWindow_login_and_regiester::on_pbtnLogin_clicked()
{
    QString username=this->ui->leUsername->text();
    QString password=this->ui->lePassword->text();

    int res=this->clnt.Login(username.toStdString().c_str(),password.toStdString().c_str());
    if(res==0){
        this->ui->login_tip->setText("用户名不存在");
    }else if(res==1){
        this->ui->login_tip->setText("密码错误");
    }else if(res==2){
        this->ui->login_tip->setText("登陆成功");

        /*此处关闭登录框，发送打开游戏界面框的信号，并传递账户信息*/

        Account ac(username.toStdString().c_str(),password.toStdString().c_str());
        emit Login(ac);

        this->close();

    }

}

void MainWindow_login_and_regiester::on_leUsername_2_textEdited(const QString &arg1)
{
    if(arg1.toLocal8Bit().length()<6){
        this->ui->tip2->setText("用户名过短");
    }else if(arg1.toLocal8Bit().length()>18){
        this->ui->tip2->setText("用户名过长");
    }else if(this->clnt.isUsernameExit(arg1.toStdString().c_str())){
        this->ui->tip2->setText("用户名已存在");
    }else{
        this->ui->tip2->setText("");
    }
}

void MainWindow_login_and_regiester::on_lePassword_2_textEdited(const QString &arg1)
{
    if(arg1.toLocal8Bit().length()<6){
        this->ui->tip3->setText("密码过短");
    }else if(arg1.toLocal8Bit().length()>18){
        this->ui->tip3->setText("密码过长");
    }else{
        this->ui->tip3->setText("");
    }
}

void MainWindow_login_and_regiester::on_lePassword_3_textEdited(const QString &arg1)
{
    if(arg1!=this->ui->lePassword_2->text()){
        this->ui->tip4->setText("前后密码不同");
    }else{
        this->ui->tip4->setText("");
    }
}

void MainWindow_login_and_regiester::on_pbtnRegister_clicked()//注册按钮
{
    QString username=this->ui->leUsername_2->text();
    QString psd1=this->ui->lePassword_2->text();
    QString psd2=this->ui->lePassword_3->text();

    if(username.toLocal8Bit().length()>=6 && username.toLocal8Bit().length()<=18)
        if(!this->clnt.isUsernameExit(username.toStdString().c_str()))
            if(psd1.toLocal8Bit().length()>=6 &&  psd1.toLocal8Bit().length()<=18)
                if(psd1==psd2){
                    /*清楚文本框内容*/
                    this->ui->leUsername_2->setText("");
                    this->ui->lePassword_2->setText("");
                    this->ui->lePassword_3->setText("");

                    /*弹出对话框，并且提示 新手大礼包:随机获取三只精灵---已放入背包，请登录游戏查收*/
                    Dialog_register dr(this);
                    dr.exec();

                    //服务器交互
                    this->clnt.Register(username.toStdString().c_str(),psd1.toStdString().c_str());

                    //切换到登陆页面
                    this->ui->tabWidget->setCurrentIndex(0);
                }

}
