#include "mainwindow.h"
#include <QApplication>


#include <stdio.h>
#include <string.h>
#include <winsock2.h>

#pragma comment (lib, "ws2_32.lib")  //加载 ws2_32.dll

#include<iostream>
#include<vector>

#include"ServerSources/Account.hpp"
#include"ServerSources/Administrators.hpp"
#include"ServerSources/PetsBag.hpp"
#include"ServerSources/PetsClass/Pets.hpp"


int main(int argc, char *argv[])
{
//    QApplication a(argc, argv);

//    MainWindow w;
//    w.show();

//    return a.exec();



    //初始化 DLL
    WSADATA wsaData;
    WSAStartup( MAKEWORD(2, 2), &wsaData);

    //创建套接字
    SOCKET servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

    //绑定套接字
    sockaddr_in sockAddr;
    memset(&sockAddr, 0, sizeof(sockAddr));  //每个字节都用0填充
    sockAddr.sin_family = PF_INET;  //使用IPv4地址
    sockAddr.sin_addr.s_addr = inet_addr("192.168.211.1");  //具体的IP地址
    sockAddr.sin_port = htons(1234);  //端口
    bind(servSock, (SOCKADDR*)&sockAddr, sizeof(SOCKADDR));

    //创建服务端管理员对象
    Administrators admin;
    cout<<"服务器运行中..."<<endl;

    //进入监听状态
    listen(servSock, 20);

    while(1)
    {
        //接收客户端请求
        SOCKADDR clntAddr;
        int nSize = sizeof(SOCKADDR);
        SOCKET clntSock = accept(servSock, (SOCKADDR*)&clntAddr, &nSize);


        //接收客户端的数据
    //	char recvData[MAXBYTE]={0};
//		recv(clntSock,recvData,MAXBYTE,0);
//		printf("Message from client: %s\n",recvData);

        int f=-1;//接收命令号
        recv(clntSock,(char*)&f,sizeof(int),0);

        if(f==0)//关闭服务器
            break;
        if(f==1)//注册
        {
            char username[20],password[20];
            recv(clntSock,username,sizeof(char)*20,0);
            recv(clntSock,password,sizeof(char)*20,0);
            cout<<username<<" "<<password<<endl;

            admin.Register(Account(username,password));

            bool res=true;
            send(clntSock,(char*)&res,sizeof(bool),0);//发送注册结果


            PetsBag pb(username);
            pb.GetThreeRandomPets();//随机获取三个精灵
//			vector<Pets> li;
//			for(vector<Pets>::iterator it=li.begin();it!=li.end();it++)
//				send(clntSock,(char*)&(*it),sizeof(Pets),0);//发送三个精灵数据
//			pb.ShowAllPetsData();//显示三只精灵数据

        }
        if(f==2)//登录
        {
            cout<<"登录"<<endl;
            char username[20],password[20];
            recv(clntSock,username,sizeof(char)*20,0);
            recv(clntSock,password,sizeof(char)*20,0);
            cout<<username<<" "<<password<<endl;

            //登录并返回登录结果
            int res=0;
            res=admin.Login(Account(username,password));
            send(clntSock,(char*)&res,sizeof(int),0);
        }
        if(f==3)//登出
        {
            cout<<"登出"<<endl;
            Account ac;
            recv(clntSock,(char*)&ac,sizeof(Account),0);


            admin.Logout(ac);
            bool res=true;
            send(clntSock,(char*)&res,sizeof(bool),0);
        }
        if(f==4)//验证用户名是否存在
        {
            cout<<"验证用户名是否存在 "<<endl;
            char username[20]="";

            recv(clntSock,username,sizeof(char)*20,0);

            bool res=false;
            res=admin.IsUsernameExit(username);
            send(clntSock,(char*)&res,sizeof(bool),0);
        }
        if(f==5)//查看当前在线用户
        {
            cout<<"查看当前在线用户 "<<endl;

            int n;
            n=admin.GetOnlineUserNum();
            send(clntSock,(char*)&n,sizeof(int),0);//发送在线用户数量


            vector<Account> li=admin.GetOnlineUserList();
            for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
                send(clntSock,(char*)&(*it),sizeof(Account),0);//发送在线用户数据

            //显示在线用户
            for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
                cout<<it->username<<endl;
        }
        if(f==6)//查看所有用户
        {
            cout<<"查看所有用户 "<<endl;

            int n;
            n=admin.GetRegisterAccountNum();
            send(clntSock,(char*)&n,sizeof(int),0);//发送所有注册用户数量


            vector<Account> li=admin.GetRegisterAccountList();
            for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
                send(clntSock,(char*)&(*it),sizeof(Account),0);//发送注册用户数据

            //显示注册用户
            for(vector<Account>::iterator it=li.begin();it!=li.end();it++)
                cout<<it->username<<endl;
        }
        if(f==7)//查看用户拥有的精灵
        {
            cout<<"查看用户拥有的精灵 "<<endl;

            char username[20];
            recv(clntSock,username,sizeof(char)*20,0);//接收指定用户的用户名

            PetsBag pb(username);
            int n=pb.GetPetsNum();
            send(clntSock,(char*)&n,sizeof(int),0);//发送目标账户精灵数量


            vector<Pets> li;
            li=pb.GetPetsList();//获取目标账户的精灵列表
            for(vector<Pets>::iterator it=li.begin();it!=li.end();it++)
                send(clntSock,(char*)&(*it),sizeof(Pets),0);//发送精灵数据

            pb.ShowAllPetsData();//显示精灵数据
        }
        if(f==8)//查看虚拟精灵列表
        {
            cout<<"查看虚拟精灵列表 "<<endl;

            int n=admin.GetVirtualPetsCount();
            send(clntSock,(char*)&n,sizeof(int),0);//发送精灵数量


            vector<Pets> li;
            li=admin.GetVirtualPetsList();//获取虚拟精灵列表
            for(vector<Pets>::iterator it=li.begin();it!=li.end();it++)
                send(clntSock,(char*)&(*it),sizeof(Pets),0);//发送精灵数据

            //显示虚拟精灵列表
            for(vector<Pets>::iterator it=li.begin();it!=li.end();it++)
                it->DataShow();
        }

//	    //向客户端发送数据---响应验证
//	    char str[100];
//		strcpy(str,"Message receive successful!");
//	    send(clntSock, str, strlen(str)+sizeof(char), 0);

        //关闭套接字
        closesocket(clntSock);
    }



    //关闭套接字
    closesocket(servSock);

    //终止 DLL 的使用
    WSACleanup();

    return 0;
}
