/********************************************************************************
** Form generated from reading UI file 'mainwindow_login_and_regiester.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_LOGIN_AND_REGIESTER_H
#define UI_MAINWINDOW_LOGIN_AND_REGIESTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow_login_and_regiester
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tabLogin;
    QPushButton *pbtnLogin;
    QLabel *lblUsername;
    QLabel *lblPassword;
    QLineEdit *leUsername;
    QLineEdit *lePassword;
    QCheckBox *cBoxAutoLogin;
    QCheckBox *cBoxKeepPassword;
    QLabel *findPassword;
    QLabel *login_tip;
    QWidget *tabRegister;
    QLabel *lblPassword_2;
    QPushButton *pbtnRegister;
    QLineEdit *lePassword_2;
    QLineEdit *leUsername_2;
    QLabel *lblUsername_2;
    QLabel *lblPassword_3;
    QLineEdit *lePassword_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *tip2;
    QLabel *tip3;
    QLabel *tip4;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow_login_and_regiester)
    {
        if (MainWindow_login_and_regiester->objectName().isEmpty())
            MainWindow_login_and_regiester->setObjectName(QString::fromUtf8("MainWindow_login_and_regiester"));
        MainWindow_login_and_regiester->resize(400, 300);
        MainWindow_login_and_regiester->setMinimumSize(QSize(400, 300));
        MainWindow_login_and_regiester->setMaximumSize(QSize(400, 300));
        centralWidget = new QWidget(MainWindow_login_and_regiester);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 401, 231));
        tabWidget->setLayoutDirection(Qt::LeftToRight);
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tabWidget->setElideMode(Qt::ElideNone);
        tabWidget->setUsesScrollButtons(true);
        tabLogin = new QWidget();
        tabLogin->setObjectName(QString::fromUtf8("tabLogin"));
        pbtnLogin = new QPushButton(tabLogin);
        pbtnLogin->setObjectName(QString::fromUtf8("pbtnLogin"));
        pbtnLogin->setGeometry(QRect(150, 160, 93, 28));
        lblUsername = new QLabel(tabLogin);
        lblUsername->setObjectName(QString::fromUtf8("lblUsername"));
        lblUsername->setGeometry(QRect(60, 30, 71, 21));
        lblPassword = new QLabel(tabLogin);
        lblPassword->setObjectName(QString::fromUtf8("lblPassword"));
        lblPassword->setGeometry(QRect(74, 70, 41, 21));
        leUsername = new QLineEdit(tabLogin);
        leUsername->setObjectName(QString::fromUtf8("leUsername"));
        leUsername->setGeometry(QRect(120, 30, 191, 21));
        lePassword = new QLineEdit(tabLogin);
        lePassword->setObjectName(QString::fromUtf8("lePassword"));
        lePassword->setGeometry(QRect(120, 70, 191, 21));
        cBoxAutoLogin = new QCheckBox(tabLogin);
        cBoxAutoLogin->setObjectName(QString::fromUtf8("cBoxAutoLogin"));
        cBoxAutoLogin->setGeometry(QRect(40, 110, 91, 19));
        cBoxAutoLogin->setLayoutDirection(Qt::RightToLeft);
        cBoxAutoLogin->setTristate(false);
        cBoxKeepPassword = new QCheckBox(tabLogin);
        cBoxKeepPassword->setObjectName(QString::fromUtf8("cBoxKeepPassword"));
        cBoxKeepPassword->setGeometry(QRect(160, 110, 91, 19));
        cBoxKeepPassword->setLayoutDirection(Qt::RightToLeft);
        cBoxKeepPassword->setTristate(false);
        findPassword = new QLabel(tabLogin);
        findPassword->setObjectName(QString::fromUtf8("findPassword"));
        findPassword->setGeometry(QRect(280, 110, 81, 21));
        login_tip = new QLabel(tabLogin);
        login_tip->setObjectName(QString::fromUtf8("login_tip"));
        login_tip->setGeometry(QRect(70, 130, 251, 31));
        QFont font;
        font.setPointSize(9);
        login_tip->setFont(font);
        login_tip->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));
        login_tip->setAlignment(Qt::AlignCenter);
        tabWidget->addTab(tabLogin, QString());
        tabRegister = new QWidget();
        tabRegister->setObjectName(QString::fromUtf8("tabRegister"));
        lblPassword_2 = new QLabel(tabRegister);
        lblPassword_2->setObjectName(QString::fromUtf8("lblPassword_2"));
        lblPassword_2->setGeometry(QRect(54, 70, 41, 21));
        pbtnRegister = new QPushButton(tabRegister);
        pbtnRegister->setObjectName(QString::fromUtf8("pbtnRegister"));
        pbtnRegister->setGeometry(QRect(150, 160, 93, 28));
        lePassword_2 = new QLineEdit(tabRegister);
        lePassword_2->setObjectName(QString::fromUtf8("lePassword_2"));
        lePassword_2->setGeometry(QRect(100, 70, 191, 21));
        leUsername_2 = new QLineEdit(tabRegister);
        leUsername_2->setObjectName(QString::fromUtf8("leUsername_2"));
        leUsername_2->setGeometry(QRect(100, 20, 191, 21));
        lblUsername_2 = new QLabel(tabRegister);
        lblUsername_2->setObjectName(QString::fromUtf8("lblUsername_2"));
        lblUsername_2->setGeometry(QRect(40, 20, 71, 21));
        lblPassword_3 = new QLabel(tabRegister);
        lblPassword_3->setObjectName(QString::fromUtf8("lblPassword_3"));
        lblPassword_3->setGeometry(QRect(24, 120, 71, 21));
        lePassword_3 = new QLineEdit(tabRegister);
        lePassword_3->setObjectName(QString::fromUtf8("lePassword_3"));
        lePassword_3->setGeometry(QRect(100, 120, 191, 21));
        label = new QLabel(tabRegister);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 40, 271, 31));
        QFont font1;
        font1.setPointSize(8);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        label->setFont(font1);
        label->setScaledContents(false);
        label_2 = new QLabel(tabRegister);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 90, 271, 31));
        label_2->setFont(font1);
        label_2->setScaledContents(false);
        tip2 = new QLabel(tabRegister);
        tip2->setObjectName(QString::fromUtf8("tip2"));
        tip2->setGeometry(QRect(300, 20, 101, 20));
        tip2->setFont(font);
        tip2->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));
        tip2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        tip3 = new QLabel(tabRegister);
        tip3->setObjectName(QString::fromUtf8("tip3"));
        tip3->setGeometry(QRect(300, 70, 101, 20));
        tip3->setFont(font);
        tip3->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));
        tip3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        tip4 = new QLabel(tabRegister);
        tip4->setObjectName(QString::fromUtf8("tip4"));
        tip4->setGeometry(QRect(300, 120, 101, 20));
        tip4->setFont(font);
        tip4->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));
        tip4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        tabWidget->addTab(tabRegister, QString());
        MainWindow_login_and_regiester->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow_login_and_regiester);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 26));
        MainWindow_login_and_regiester->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow_login_and_regiester);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow_login_and_regiester->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow_login_and_regiester);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow_login_and_regiester->setStatusBar(statusBar);

        retranslateUi(MainWindow_login_and_regiester);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow_login_and_regiester);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow_login_and_regiester)
    {
        MainWindow_login_and_regiester->setWindowTitle(QApplication::translate("MainWindow_login_and_regiester", "PoPokemon_\346\270\270\346\210\217\345\205\245\345\217\243", nullptr));
        pbtnLogin->setText(QApplication::translate("MainWindow_login_and_regiester", "\347\231\273\345\275\225", nullptr));
        lblUsername->setText(QApplication::translate("MainWindow_login_and_regiester", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        lblPassword->setText(QApplication::translate("MainWindow_login_and_regiester", "\345\257\206\347\240\201\357\274\232", nullptr));
        leUsername->setText(QApplication::translate("MainWindow_login_and_regiester", "hong123", nullptr));
        lePassword->setText(QApplication::translate("MainWindow_login_and_regiester", "123456", nullptr));
        cBoxAutoLogin->setText(QApplication::translate("MainWindow_login_and_regiester", "\350\207\252\345\212\250\347\231\273\345\275\225", nullptr));
        cBoxKeepPassword->setText(QApplication::translate("MainWindow_login_and_regiester", "\350\256\260\344\275\217\345\257\206\347\240\201", nullptr));
        findPassword->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\211\276\345\233\236\345\257\206\347\240\201", nullptr));
        login_tip->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\217\220\347\244\2721", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tabLogin), QApplication::translate("MainWindow_login_and_regiester", "\347\231\273\345\275\225", nullptr));
        lblPassword_2->setText(QApplication::translate("MainWindow_login_and_regiester", "\345\257\206\347\240\201\357\274\232", nullptr));
        pbtnRegister->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\263\250\345\206\214", nullptr));
        lblUsername_2->setText(QApplication::translate("MainWindow_login_and_regiester", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        lblPassword_3->setText(QApplication::translate("MainWindow_login_and_regiester", "\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", nullptr));
        lePassword_3->setText(QString());
        label->setText(QApplication::translate("MainWindow_login_and_regiester", "\347\224\250\346\210\267\345\220\215\347\224\261\346\225\260\345\255\227\343\200\201\345\255\227\346\257\215\343\200\201\344\270\213\345\210\222\347\272\277\347\273\204\346\210\220\357\274\214\351\225\277\345\272\2466-18", nullptr));
        label_2->setText(QApplication::translate("MainWindow_login_and_regiester", "\345\257\206\347\240\201\347\224\261\346\225\260\345\255\227\343\200\201\345\255\227\346\257\215\343\200\201\344\270\213\345\210\222\347\272\277\347\273\204\346\210\220\357\274\214\351\225\277\345\272\2466-18", nullptr));
        tip2->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\217\220\347\244\2722", nullptr));
        tip3->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\217\220\347\244\2723", nullptr));
        tip4->setText(QApplication::translate("MainWindow_login_and_regiester", "\346\217\220\347\244\2724", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tabRegister), QApplication::translate("MainWindow_login_and_regiester", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow_login_and_regiester: public Ui_MainWindow_login_and_regiester {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_LOGIN_AND_REGIESTER_H
