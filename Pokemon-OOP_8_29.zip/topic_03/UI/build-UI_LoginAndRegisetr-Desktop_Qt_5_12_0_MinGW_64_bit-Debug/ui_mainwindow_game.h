/********************************************************************************
** Form generated from reading UI file 'mainwindow_game.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_GAME_H
#define UI_MAINWINDOW_GAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow_game
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *myDataPage;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *leUsername;
    QLabel *label_3;
    QLineEdit *lePetsCount;
    QLabel *label_4;
    QLineEdit *leRateOfWinning;
    QLabel *label_5;
    QLineEdit *lePetsCountBadge;
    QLineEdit *leHigherPetsBadge;
    QLabel *label_6;
    QLineEdit *lePCoinCount;
    QLabel *label_8;
    QPushButton *pushButton;
    QTabWidget *tabWidget_PetsBag;
    QWidget *tab_0;
    QTableView *tbvMyPetsBag;
    QWidget *tab_1;
    QTableView *tbvOnlineUserList;
    QWidget *tab_2;
    QTableView *tbvRegisterUserList;
    QPushButton *pBtnOutGame;
    QPushButton *pushButton_2;
    QWidget *levelUpBattlePage;
    QWidget *combatPage;
    QWidget *tab;
    QLabel *label_7;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow_game)
    {
        if (MainWindow_game->objectName().isEmpty())
            MainWindow_game->setObjectName(QString::fromUtf8("MainWindow_game"));
        MainWindow_game->resize(792, 450);
        centralwidget = new QWidget(MainWindow_game);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 791, 381));
        tabWidget->setFocusPolicy(Qt::TabFocus);
        tabWidget->setLayoutDirection(Qt::LeftToRight);
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tabWidget->setIconSize(QSize(16, 16));
        myDataPage = new QWidget();
        myDataPage->setObjectName(QString::fromUtf8("myDataPage"));
        myDataPage->setLayoutDirection(Qt::LeftToRight);
        label = new QLabel(myDataPage);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 91, 91));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));
        label->setPixmap(QPixmap(QString::fromUtf8(":/new/image/image/cat.png")));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(myDataPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(100, 10, 71, 21));
        leUsername = new QLineEdit(myDataPage);
        leUsername->setObjectName(QString::fromUtf8("leUsername"));
        leUsername->setEnabled(false);
        leUsername->setGeometry(QRect(160, 10, 111, 21));
        label_3 = new QLabel(myDataPage);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(100, 40, 71, 21));
        lePetsCount = new QLineEdit(myDataPage);
        lePetsCount->setObjectName(QString::fromUtf8("lePetsCount"));
        lePetsCount->setEnabled(false);
        lePetsCount->setGeometry(QRect(180, 40, 91, 21));
        label_4 = new QLabel(myDataPage);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(100, 70, 61, 21));
        leRateOfWinning = new QLineEdit(myDataPage);
        leRateOfWinning->setObjectName(QString::fromUtf8("leRateOfWinning"));
        leRateOfWinning->setEnabled(false);
        leRateOfWinning->setGeometry(QRect(150, 70, 121, 21));
        label_5 = new QLabel(myDataPage);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(290, 10, 111, 21));
        lePetsCountBadge = new QLineEdit(myDataPage);
        lePetsCountBadge->setObjectName(QString::fromUtf8("lePetsCountBadge"));
        lePetsCountBadge->setEnabled(false);
        lePetsCountBadge->setGeometry(QRect(400, 10, 111, 21));
        leHigherPetsBadge = new QLineEdit(myDataPage);
        leHigherPetsBadge->setObjectName(QString::fromUtf8("leHigherPetsBadge"));
        leHigherPetsBadge->setEnabled(false);
        leHigherPetsBadge->setGeometry(QRect(400, 40, 111, 21));
        label_6 = new QLabel(myDataPage);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(290, 40, 111, 21));
        lePCoinCount = new QLineEdit(myDataPage);
        lePCoinCount->setObjectName(QString::fromUtf8("lePCoinCount"));
        lePCoinCount->setEnabled(false);
        lePCoinCount->setGeometry(QRect(330, 70, 121, 21));
        label_8 = new QLabel(myDataPage);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(290, 70, 61, 21));
        pushButton = new QPushButton(myDataPage);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(460, 70, 51, 21));
        QFont font;
        font.setPointSize(8);
        pushButton->setFont(font);
        tabWidget_PetsBag = new QTabWidget(myDataPage);
        tabWidget_PetsBag->setObjectName(QString::fromUtf8("tabWidget_PetsBag"));
        tabWidget_PetsBag->setGeometry(QRect(0, 100, 791, 261));
        tab_0 = new QWidget();
        tab_0->setObjectName(QString::fromUtf8("tab_0"));
        tbvMyPetsBag = new QTableView(tab_0);
        tbvMyPetsBag->setObjectName(QString::fromUtf8("tbvMyPetsBag"));
        tbvMyPetsBag->setGeometry(QRect(0, 0, 791, 231));
        tabWidget_PetsBag->addTab(tab_0, QString());
        tab_1 = new QWidget();
        tab_1->setObjectName(QString::fromUtf8("tab_1"));
        tbvOnlineUserList = new QTableView(tab_1);
        tbvOnlineUserList->setObjectName(QString::fromUtf8("tbvOnlineUserList"));
        tbvOnlineUserList->setGeometry(QRect(0, 0, 791, 231));
        tabWidget_PetsBag->addTab(tab_1, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        tbvRegisterUserList = new QTableView(tab_2);
        tbvRegisterUserList->setObjectName(QString::fromUtf8("tbvRegisterUserList"));
        tbvRegisterUserList->setGeometry(QRect(0, 0, 791, 231));
        tabWidget_PetsBag->addTab(tab_2, QString());
        pBtnOutGame = new QPushButton(myDataPage);
        pBtnOutGame->setObjectName(QString::fromUtf8("pBtnOutGame"));
        pBtnOutGame->setGeometry(QRect(680, 40, 93, 28));
        pushButton_2 = new QPushButton(myDataPage);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 10, 93, 28));
        tabWidget->addTab(myDataPage, QString());
        levelUpBattlePage = new QWidget();
        levelUpBattlePage->setObjectName(QString::fromUtf8("levelUpBattlePage"));
        tabWidget->addTab(levelUpBattlePage, QString());
        combatPage = new QWidget();
        combatPage->setObjectName(QString::fromUtf8("combatPage"));
        tabWidget->addTab(combatPage, QString());
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        label_7 = new QLabel(tab);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(150, 110, 511, 111));
        QFont font1;
        font1.setPointSize(20);
        label_7->setFont(font1);
        tabWidget->addTab(tab, QString());
        MainWindow_game->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow_game);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 792, 26));
        MainWindow_game->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow_game);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow_game->setStatusBar(statusbar);

        retranslateUi(MainWindow_game);
        QObject::connect(pBtnOutGame, SIGNAL(clicked()), MainWindow_game, SLOT(close()));

        tabWidget->setCurrentIndex(1);
        tabWidget_PetsBag->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow_game);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow_game)
    {
        MainWindow_game->setWindowTitle(QApplication::translate("MainWindow_game", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QApplication::translate("MainWindow_game", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        leUsername->setText(QApplication::translate("MainWindow_game", "hong", nullptr));
        label_3->setText(QApplication::translate("MainWindow_game", "\347\262\276\347\201\265\346\225\260\351\207\217\357\274\232", nullptr));
        lePetsCount->setText(QApplication::translate("MainWindow_game", "15", nullptr));
        label_4->setText(QApplication::translate("MainWindow_game", "\350\203\234\347\216\207\357\274\232", nullptr));
        leRateOfWinning->setText(QApplication::translate("MainWindow_game", "15%", nullptr));
        label_5->setText(QApplication::translate("MainWindow_game", "\345\256\240\347\211\251\344\270\252\346\225\260\345\276\275\347\253\240\357\274\232", nullptr));
        lePetsCountBadge->setText(QApplication::translate("MainWindow_game", "\351\207\221\347\211\214", nullptr));
        leHigherPetsBadge->setText(QApplication::translate("MainWindow_game", "\351\207\221\347\211\214", nullptr));
        label_6->setText(QApplication::translate("MainWindow_game", "\351\253\230\347\272\247\345\256\240\347\211\251\345\276\275\347\253\240\357\274\232", nullptr));
        lePCoinCount->setText(QApplication::translate("MainWindow_game", "1000", nullptr));
        label_8->setText(QApplication::translate("MainWindow_game", "P\345\270\201\357\274\232", nullptr));
        pushButton->setText(QApplication::translate("MainWindow_game", "\345\205\205\345\200\274", nullptr));
        tabWidget_PetsBag->setTabText(tabWidget_PetsBag->indexOf(tab_0), QApplication::translate("MainWindow_game", "\345\256\240\347\211\251\350\203\214\345\214\205", nullptr));
        tabWidget_PetsBag->setTabText(tabWidget_PetsBag->indexOf(tab_1), QApplication::translate("MainWindow_game", "\345\234\250\347\272\277\347\224\250\346\210\267\345\210\227\350\241\250", nullptr));
        tabWidget_PetsBag->setTabText(tabWidget_PetsBag->indexOf(tab_2), QApplication::translate("MainWindow_game", "\346\211\200\346\234\211\347\224\250\346\210\267\345\210\227\350\241\250", nullptr));
        pBtnOutGame->setText(QApplication::translate("MainWindow_game", "\351\200\200\345\207\272\346\270\270\346\210\217", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow_game", "\345\210\207\346\215\242\350\264\246\345\217\267", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(myDataPage), QApplication::translate("MainWindow_game", "\346\210\221\347\232\204\350\265\204\346\226\231", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(levelUpBattlePage), QApplication::translate("MainWindow_game", "\345\215\207\347\272\247\350\265\233", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(combatPage), QApplication::translate("MainWindow_game", "\345\206\263\346\226\227\350\265\233", nullptr));
        label_7->setText(QApplication::translate("MainWindow_game", "\345\212\237\350\203\275\345\260\232\345\234\250\345\274\200\345\217\221\344\270\255\343\200\202\343\200\202\343\200\202\346\225\254\350\257\267\346\234\237\345\276\205", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow_game", "\345\256\240\347\211\251\345\225\206\345\272\227", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow_game: public Ui_MainWindow_game {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_GAME_H
