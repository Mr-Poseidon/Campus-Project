/********************************************************************************
** Form generated from reading UI file 'dialog_register.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_REGISTER_H
#define UI_DIALOG_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialog_register
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *Dialog_register)
    {
        if (Dialog_register->objectName().isEmpty())
            Dialog_register->setObjectName(QString::fromUtf8("Dialog_register"));
        Dialog_register->resize(394, 161);
        buttonBox = new QDialogButtonBox(Dialog_register);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 110, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(Dialog_register);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 391, 31));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(218, 218, 218);"));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(Dialog_register);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 30, 391, 41));
        QFont font1;
        font1.setPointSize(10);
        label_2->setFont(font1);
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(218, 218, 218);"));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(Dialog_register);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(0, 60, 391, 41));
        label_3->setFont(font1);
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(218, 218, 218);"));
        label_3->setAlignment(Qt::AlignCenter);

        retranslateUi(Dialog_register);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog_register, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog_register, SLOT(reject()));

        QMetaObject::connectSlotsByName(Dialog_register);
    } // setupUi

    void retranslateUi(QDialog *Dialog_register)
    {
        Dialog_register->setWindowTitle(QApplication::translate("Dialog_register", "\346\263\250\345\206\214\346\210\220\345\212\237", nullptr));
        label->setText(QApplication::translate("Dialog_register", "\346\226\260\346\211\213\345\244\247\347\244\274\345\214\205", nullptr));
        label_2->setText(QApplication::translate("Dialog_register", "\351\232\217\346\234\272\350\216\267\345\217\226\344\270\211\345\217\252\347\262\276\347\201\265---\345\267\262\346\224\276\345\205\245\350\203\214\345\214\205", nullptr));
        label_3->setText(QApplication::translate("Dialog_register", "\350\257\267\347\231\273\345\275\225\346\270\270\346\210\217\346\237\245\346\224\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_register: public Ui_Dialog_register {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_REGISTER_H
