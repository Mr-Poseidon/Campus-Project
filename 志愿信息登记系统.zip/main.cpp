#include<iostream>
#include<cstdio>
#include<cstdlib> 

#include"Student.hpp"
#include"Major.hpp"
#include"Register.hpp"
#include"Store.hpp"
using namespace std;

void inputError(){cout<<"�����������������"<<endl;};

//�˵�ģ�� 
void Menu()
{
	do
	{
		system("cls");
		   	cout << "             ��ӭʹ��־Ը��Ϣ�Ǽ�ϵͳ " << endl
			<< ' ' << "-----------------------------------------------------" << endl
			<< ' ' << "ح               1:¼�뿼����Ϣ                   ح " << endl
			<< ' ' << "ح               2:��ѯ������Ϣ                   ح " << endl
			<< ' ' << "ح               3:¼��רҵ��Ϣ                   ح " << endl
			<< ' ' << "ح               4:��ѯרҵ��Ϣ                   ح " << endl
			<< ' ' << "ح               5:¼��־Ը�Ǽ���Ϣ               ح " << endl
			<< ' ' << "ح               6:��ѯ־Ը�Ǽ���Ϣ�����ţ�       ح " << endl
			<< ' ' << "ح               7:��ѯ־Ը�Ǽ���Ϣ���������룩   ح " << endl
			<< ' ' << "ح               0:�˳�                           ح " << endl
			<< ' ' << "-----------------------------------------------------" << endl;
		int op;
		cin >> op;
		bool f=false;
		switch (op)
		{
			case 0:f=true;break;
			case 1:Student::add();system("pause");break;
			case 2:Student::find();system("pause");break;
			case 3:Major::add();system("pause");break;
			case 4:Major::find();system("pause");break;
			case 5:Register::add();system("pause");break;
			case 6:Register::findByStudentId();system("pause");break;
			case 7:Register::findByEnrollmentCode();system("pause");break;
			default:inputError();system("pause");
		}
		if(f)break;
	} while(1);
}

int main()
{
	//��ȡ��Ϣ 
	s.Deserialize(students,"Student.txt");
	s.Deserialize(majors,"Major.txt");
	s.Deserialize(registers,"Register.txt");
	
	Menu();
	
	//������Ϣ 
	s.Serialize(students,"Student.txt");
	s.Serialize(majors,"Major.txt");
	s.Serialize(registers,"Register.txt");
	return 0;
}
