#ifndef PARKINGAREA_H
#define PARKINGAREA_H

#include "data.h"
#include "my_time.h"

#define rowCarNum 9 //һ�ų�λ���� 
#define carSiteWidth 12 //��λ�� 
#define carSiteHigh 13 //��λ�� 
#define passageWayWidth 5 //������ 
#define parkingAreaWidth ((1+carSiteWidth)*rowCarNum+1)

int Pnum=1;

void head()//̧ͷ���� 
{
	int i;
	for(i=0;i<(parkingAreaWidth/2)-10;i++)
		printf(" ");
	printf("1.ͣ�����ֲ�ͼ��ʹ�����"); 
//	for(i=0;i<(parkingAreaWidth/2)-1;i++)
//		printf(" ");
	printf("\n"); 
	return;
}

void parkingSiteRow()//������λ 
{
	int i,j,k;
	
	
	for(i=0;i<parkingAreaWidth;i++)
		printf("*");
	printf("\n");
	
	for(i=0;i<1;i++)//��λ�ϰ벿�� 
	{
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<carSiteWidth;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	
	for(i=0;i<1;i++)//���ݲ���--��λ��� 
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<4;k++)
				printf(" ");
			
			printf("P%03d",P[t++].num);
			
			for(k=0;k<4;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--ʹ��״̬ 
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			
			if(P[t++].state==0)
			{
				for(k=0;k<4;k++)
					printf(" ");	
				printf("����");
				for(k=0;k<4;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<3;k++)
					printf(" ");	
				printf("ʹ����");
				for(k=0;k<3;k++)
					printf(" ");
			}
			
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--���ƺ��� 
	{
		int t=Pnum; 
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			
			if(P[t].state==0)
			{
				for(k=0;k<2;k++)
					printf(" ");	
				printf("--------");	
				for(k=0;k<2;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<2;k++)
					printf(" ");	
//				printf("��A00001");	
				printf("%s",P[t].car_num);	
				for(k=0;k<2;k++)
					printf(" ");
			}
			t++;
		}	
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//����
	{
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<carSiteWidth;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--��ʼ������ 
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			if(P[t].state==0)
			{
				for(k=0;k<2;k++)
					printf(" ");	
				printf("--------");	
				for(k=0;k<2;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<1;k++)
					printf(" ");
				show_year(P[t].time_start);
				for(k=0;k<1;k++)
					printf(" ");
			}
			t++;	
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--��ʼʱ����
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			if(P[t].state==0)
			{
				for(k=0;k<2;k++)
					printf(" ");	
				printf("--------");	
				for(k=0;k<2;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<2;k++)
					printf(" ");
				show_hour(P[t].time_start);
				for(k=0;k<2;k++)
					printf(" ");
			}
			t++;	
		}
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--ʱ������� 
	{
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<5;k++)
				printf(" ");
			
			printf("��");
			
			for(k=0;k<5;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	
	for(i=0;i<1;i++)//���ݲ���--���������� 
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			if(P[t].state==0)
			{
				for(k=0;k<2;k++)
					printf(" ");	
				printf("--------");	
				for(k=0;k<2;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<1;k++)
					printf(" ");
				show_year(P[t].time_end);
				for(k=0;k<1;k++)
					printf(" ");
			}
			t++;	
		}
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--����ʱ����
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			if(P[t].state==0)
			{
				for(k=0;k<2;k++)
					printf(" ");	
				printf("--------");	
				for(k=0;k<2;k++)
					printf(" ");
			}
			else
			{
				for(k=0;k<2;k++)
					printf(" ");
				show_hour(P[t].time_end);
				for(k=0;k<2;k++)
					printf(" ");
			}
			t++;	
		}
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//����
	{
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<carSiteWidth;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//���ݲ���--��ĿǰΪֹ��ͣ������
	{
		int t=Pnum;
		for(j=0;j<rowCarNum;j++)
		{
		
			if(P[t].state==0)
			{
				printf("*");
				for(k=0;k<5;k++)
					printf(" ");
				printf("��");
				for(k=0;k<5;k++)
					printf(" ");
			}
			else
			{
				printf("*");
				for(k=0;k<3;k++)
					printf(" ");
				printf("%4dԪ",P[t].cost);
				for(k=0;k<3;k++)
					printf(" ");
			} 	
			t++;
		}			
		printf("*");
		printf("\n");
	}
	
	
	
	for(i=0;i<1;i++)//��λ�°벿�� 
	{
		for(j=0;j<rowCarNum;j++)
		{
			printf("*");
			for(k=0;k<carSiteWidth;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	
	for(i=0;i<parkingAreaWidth;i++)
		printf("*");
	printf("\n");	
} 
void passageWay()//���� 
{
	int i,j,k;
	
	for(i=0;i<2;i++)//���� 
	{
		printf("*");
		for(j=0;j<parkingAreaWidth-2;j++)
			printf(" ");
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<1;i++)//����--ͼ�� 
	{
		printf("*");
		for(j=0;j<carSiteWidth;j++)//��һ����λ 
			printf(" ");
			
		for(j=0;j<rowCarNum-1;j++)
		{
			printf("����");
			for(k=0;k<9;k++)
				printf(" ");
		}
			
		printf("*");
		printf("\n");
	}
	
	for(i=0;i<2;i++)//����
	{
		printf("*");
		for(j=0;j<parkingAreaWidth-2;j++)
			printf(" ");
		printf("*");
		printf("\n");
	}
}
void areaShow()
{
	updataData();//����ʵʱ��Ϣ 
	
	head(); 
	
	Pnum=1;
	parkingSiteRow();
	
	passageWay();
	
	Pnum+=rowCarNum;
	parkingSiteRow();		
}

#endif 

