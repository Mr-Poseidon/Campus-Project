/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../DijkstraProjectUI/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[50];
    char stringdata0[1288];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 24), // "on_radioButton_4_clicked"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 26), // "on_spinBox1_2_valueChanged"
QT_MOC_LITERAL(4, 64, 4), // "arg1"
QT_MOC_LITERAL(5, 69, 26), // "on_spinBox1_3_valueChanged"
QT_MOC_LITERAL(6, 96, 26), // "on_spinBox1_4_valueChanged"
QT_MOC_LITERAL(7, 123, 26), // "on_spinBox1_5_valueChanged"
QT_MOC_LITERAL(8, 150, 26), // "on_spinBox1_6_valueChanged"
QT_MOC_LITERAL(9, 177, 26), // "on_spinBox1_7_valueChanged"
QT_MOC_LITERAL(10, 204, 26), // "on_spinBox1_8_valueChanged"
QT_MOC_LITERAL(11, 231, 26), // "on_spinBox1_9_valueChanged"
QT_MOC_LITERAL(12, 258, 27), // "on_spinBox1_10_valueChanged"
QT_MOC_LITERAL(13, 286, 26), // "on_spinBox2_3_valueChanged"
QT_MOC_LITERAL(14, 313, 26), // "on_spinBox2_4_valueChanged"
QT_MOC_LITERAL(15, 340, 26), // "on_spinBox2_5_valueChanged"
QT_MOC_LITERAL(16, 367, 26), // "on_spinBox2_6_valueChanged"
QT_MOC_LITERAL(17, 394, 26), // "on_spinBox2_7_valueChanged"
QT_MOC_LITERAL(18, 421, 26), // "on_spinBox2_8_valueChanged"
QT_MOC_LITERAL(19, 448, 26), // "on_spinBox2_9_valueChanged"
QT_MOC_LITERAL(20, 475, 27), // "on_spinBox2_10_valueChanged"
QT_MOC_LITERAL(21, 503, 26), // "on_spinBox3_4_valueChanged"
QT_MOC_LITERAL(22, 530, 26), // "on_spinBox3_5_valueChanged"
QT_MOC_LITERAL(23, 557, 26), // "on_spinBox3_6_valueChanged"
QT_MOC_LITERAL(24, 584, 26), // "on_spinBox3_7_valueChanged"
QT_MOC_LITERAL(25, 611, 26), // "on_spinBox3_8_valueChanged"
QT_MOC_LITERAL(26, 638, 26), // "on_spinBox3_9_valueChanged"
QT_MOC_LITERAL(27, 665, 27), // "on_spinBox3_10_valueChanged"
QT_MOC_LITERAL(28, 693, 26), // "on_spinBox4_5_valueChanged"
QT_MOC_LITERAL(29, 720, 26), // "on_spinBox4_6_valueChanged"
QT_MOC_LITERAL(30, 747, 26), // "on_spinBox4_7_valueChanged"
QT_MOC_LITERAL(31, 774, 26), // "on_spinBox4_8_valueChanged"
QT_MOC_LITERAL(32, 801, 26), // "on_spinBox4_9_valueChanged"
QT_MOC_LITERAL(33, 828, 27), // "on_spinBox4_10_valueChanged"
QT_MOC_LITERAL(34, 856, 26), // "on_spinBox5_6_valueChanged"
QT_MOC_LITERAL(35, 883, 26), // "on_spinBox5_7_valueChanged"
QT_MOC_LITERAL(36, 910, 26), // "on_spinBox5_8_valueChanged"
QT_MOC_LITERAL(37, 937, 26), // "on_spinBox5_9_valueChanged"
QT_MOC_LITERAL(38, 964, 27), // "on_spinBox5_10_valueChanged"
QT_MOC_LITERAL(39, 992, 26), // "on_spinBox6_7_valueChanged"
QT_MOC_LITERAL(40, 1019, 26), // "on_spinBox6_8_valueChanged"
QT_MOC_LITERAL(41, 1046, 26), // "on_spinBox6_9_valueChanged"
QT_MOC_LITERAL(42, 1073, 27), // "on_spinBox6_10_valueChanged"
QT_MOC_LITERAL(43, 1101, 26), // "on_spinBox7_8_valueChanged"
QT_MOC_LITERAL(44, 1128, 26), // "on_spinBox7_9_valueChanged"
QT_MOC_LITERAL(45, 1155, 27), // "on_spinBox7_10_valueChanged"
QT_MOC_LITERAL(46, 1183, 26), // "on_spinBox8_9_valueChanged"
QT_MOC_LITERAL(47, 1210, 27), // "on_spinBox8_10_valueChanged"
QT_MOC_LITERAL(48, 1238, 27), // "on_spinBox9_10_valueChanged"
QT_MOC_LITERAL(49, 1266, 21) // "on_pushButton_clicked"

    },
    "MainWindow\0on_radioButton_4_clicked\0"
    "\0on_spinBox1_2_valueChanged\0arg1\0"
    "on_spinBox1_3_valueChanged\0"
    "on_spinBox1_4_valueChanged\0"
    "on_spinBox1_5_valueChanged\0"
    "on_spinBox1_6_valueChanged\0"
    "on_spinBox1_7_valueChanged\0"
    "on_spinBox1_8_valueChanged\0"
    "on_spinBox1_9_valueChanged\0"
    "on_spinBox1_10_valueChanged\0"
    "on_spinBox2_3_valueChanged\0"
    "on_spinBox2_4_valueChanged\0"
    "on_spinBox2_5_valueChanged\0"
    "on_spinBox2_6_valueChanged\0"
    "on_spinBox2_7_valueChanged\0"
    "on_spinBox2_8_valueChanged\0"
    "on_spinBox2_9_valueChanged\0"
    "on_spinBox2_10_valueChanged\0"
    "on_spinBox3_4_valueChanged\0"
    "on_spinBox3_5_valueChanged\0"
    "on_spinBox3_6_valueChanged\0"
    "on_spinBox3_7_valueChanged\0"
    "on_spinBox3_8_valueChanged\0"
    "on_spinBox3_9_valueChanged\0"
    "on_spinBox3_10_valueChanged\0"
    "on_spinBox4_5_valueChanged\0"
    "on_spinBox4_6_valueChanged\0"
    "on_spinBox4_7_valueChanged\0"
    "on_spinBox4_8_valueChanged\0"
    "on_spinBox4_9_valueChanged\0"
    "on_spinBox4_10_valueChanged\0"
    "on_spinBox5_6_valueChanged\0"
    "on_spinBox5_7_valueChanged\0"
    "on_spinBox5_8_valueChanged\0"
    "on_spinBox5_9_valueChanged\0"
    "on_spinBox5_10_valueChanged\0"
    "on_spinBox6_7_valueChanged\0"
    "on_spinBox6_8_valueChanged\0"
    "on_spinBox6_9_valueChanged\0"
    "on_spinBox6_10_valueChanged\0"
    "on_spinBox7_8_valueChanged\0"
    "on_spinBox7_9_valueChanged\0"
    "on_spinBox7_10_valueChanged\0"
    "on_spinBox8_9_valueChanged\0"
    "on_spinBox8_10_valueChanged\0"
    "on_spinBox9_10_valueChanged\0"
    "on_pushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      47,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  249,    2, 0x08 /* Private */,
       3,    1,  250,    2, 0x08 /* Private */,
       5,    1,  253,    2, 0x08 /* Private */,
       6,    1,  256,    2, 0x08 /* Private */,
       7,    1,  259,    2, 0x08 /* Private */,
       8,    1,  262,    2, 0x08 /* Private */,
       9,    1,  265,    2, 0x08 /* Private */,
      10,    1,  268,    2, 0x08 /* Private */,
      11,    1,  271,    2, 0x08 /* Private */,
      12,    1,  274,    2, 0x08 /* Private */,
      13,    1,  277,    2, 0x08 /* Private */,
      14,    1,  280,    2, 0x08 /* Private */,
      15,    1,  283,    2, 0x08 /* Private */,
      16,    1,  286,    2, 0x08 /* Private */,
      17,    1,  289,    2, 0x08 /* Private */,
      18,    1,  292,    2, 0x08 /* Private */,
      19,    1,  295,    2, 0x08 /* Private */,
      20,    1,  298,    2, 0x08 /* Private */,
      21,    1,  301,    2, 0x08 /* Private */,
      22,    1,  304,    2, 0x08 /* Private */,
      23,    1,  307,    2, 0x08 /* Private */,
      24,    1,  310,    2, 0x08 /* Private */,
      25,    1,  313,    2, 0x08 /* Private */,
      26,    1,  316,    2, 0x08 /* Private */,
      27,    1,  319,    2, 0x08 /* Private */,
      28,    1,  322,    2, 0x08 /* Private */,
      29,    1,  325,    2, 0x08 /* Private */,
      30,    1,  328,    2, 0x08 /* Private */,
      31,    1,  331,    2, 0x08 /* Private */,
      32,    1,  334,    2, 0x08 /* Private */,
      33,    1,  337,    2, 0x08 /* Private */,
      34,    1,  340,    2, 0x08 /* Private */,
      35,    1,  343,    2, 0x08 /* Private */,
      36,    1,  346,    2, 0x08 /* Private */,
      37,    1,  349,    2, 0x08 /* Private */,
      38,    1,  352,    2, 0x08 /* Private */,
      39,    1,  355,    2, 0x08 /* Private */,
      40,    1,  358,    2, 0x08 /* Private */,
      41,    1,  361,    2, 0x08 /* Private */,
      42,    1,  364,    2, 0x08 /* Private */,
      43,    1,  367,    2, 0x08 /* Private */,
      44,    1,  370,    2, 0x08 /* Private */,
      45,    1,  373,    2, 0x08 /* Private */,
      46,    1,  376,    2, 0x08 /* Private */,
      47,    1,  379,    2, 0x08 /* Private */,
      48,    1,  382,    2, 0x08 /* Private */,
      49,    0,  385,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_radioButton_4_clicked(); break;
        case 1: _t->on_spinBox1_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_spinBox1_3_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_spinBox1_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_spinBox1_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_spinBox1_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_spinBox1_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_spinBox1_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_spinBox1_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_spinBox1_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_spinBox2_3_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_spinBox2_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_spinBox2_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_spinBox2_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_spinBox2_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_spinBox2_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_spinBox2_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_spinBox2_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_spinBox3_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_spinBox3_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_spinBox3_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_spinBox3_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_spinBox3_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_spinBox3_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_spinBox3_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->on_spinBox4_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_spinBox4_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->on_spinBox4_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->on_spinBox4_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->on_spinBox4_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->on_spinBox4_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->on_spinBox5_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->on_spinBox5_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->on_spinBox5_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->on_spinBox5_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->on_spinBox5_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->on_spinBox6_7_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: _t->on_spinBox6_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->on_spinBox6_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->on_spinBox6_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->on_spinBox7_8_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->on_spinBox7_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->on_spinBox7_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 43: _t->on_spinBox8_9_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->on_spinBox8_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 45: _t->on_spinBox9_10_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 46: _t->on_pushButton_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 47)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 47;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
