#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_radioButton_4_clicked();

    void on_spinBox1_2_valueChanged(int arg1);
    void on_spinBox1_3_valueChanged(int arg1);
    void on_spinBox1_4_valueChanged(int arg1);
    void on_spinBox1_5_valueChanged(int arg1);
    void on_spinBox1_6_valueChanged(int arg1);
    void on_spinBox1_7_valueChanged(int arg1);
    void on_spinBox1_8_valueChanged(int arg1);
    void on_spinBox1_9_valueChanged(int arg1);
    void on_spinBox1_10_valueChanged(int arg1);

    void on_spinBox2_3_valueChanged(int arg1);
    void on_spinBox2_4_valueChanged(int arg1);
    void on_spinBox2_5_valueChanged(int arg1);
    void on_spinBox2_6_valueChanged(int arg1);
    void on_spinBox2_7_valueChanged(int arg1);
    void on_spinBox2_8_valueChanged(int arg1);
    void on_spinBox2_9_valueChanged(int arg1);
    void on_spinBox2_10_valueChanged(int arg1);

    void on_spinBox3_4_valueChanged(int arg1);
    void on_spinBox3_5_valueChanged(int arg1);
    void on_spinBox3_6_valueChanged(int arg1);
    void on_spinBox3_7_valueChanged(int arg1);
    void on_spinBox3_8_valueChanged(int arg1);
    void on_spinBox3_9_valueChanged(int arg1);
    void on_spinBox3_10_valueChanged(int arg1);

    void on_spinBox4_5_valueChanged(int arg1);
    void on_spinBox4_6_valueChanged(int arg1);
    void on_spinBox4_7_valueChanged(int arg1);
    void on_spinBox4_8_valueChanged(int arg1);
    void on_spinBox4_9_valueChanged(int arg1);
    void on_spinBox4_10_valueChanged(int arg1);

    void on_spinBox5_6_valueChanged(int arg1);
    void on_spinBox5_7_valueChanged(int arg1);
    void on_spinBox5_8_valueChanged(int arg1);
    void on_spinBox5_9_valueChanged(int arg1);
    void on_spinBox5_10_valueChanged(int arg1);

    void on_spinBox6_7_valueChanged(int arg1);
    void on_spinBox6_8_valueChanged(int arg1);
    void on_spinBox6_9_valueChanged(int arg1);
    void on_spinBox6_10_valueChanged(int arg1);

    void on_spinBox7_8_valueChanged(int arg1);
    void on_spinBox7_9_valueChanged(int arg1);
    void on_spinBox7_10_valueChanged(int arg1);

    void on_spinBox8_9_valueChanged(int arg1);
    void on_spinBox8_10_valueChanged(int arg1);


    void on_spinBox9_10_valueChanged(int arg1);



    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
