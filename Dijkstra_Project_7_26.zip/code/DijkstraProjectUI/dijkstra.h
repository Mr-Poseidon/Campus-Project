#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include<stdio.h>
#include<QString>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#define maxv 100
#define INF 1e7


static int cost[maxv][maxv];//边的权值
static int d[maxv];//指定点到达该点的最小权值
static int used[maxv];//判断该点是否使用过

static int from[maxv];//记录来源节点
static QString path[maxv];
static int vx;//节点数
//static int edge;//边数
static int ori;//出发点

QString getPath_1(int ve);//提前声明
QString getPath_2(int ve);
QString getPath_3(int ve);
QString getPath_4(int ve);
QString getPath_5(int ve);
QString getPath_6(int ve);
QString getPath_7(int ve);
QString getPath_8(int ve);


void dataInit()
{
    vx=7;
    ori=1;

//    for(int i=1;i<=vx;i++)//边初始化
//        for(j=1;j<=vx;j++)
//            cost[i][j]=INF;

    for(int i=1;i<10;i++)//无向图双向边同值
        for(int j=i+1;j<=10;j++)
        {
            cost[j][i]=cost[i][j];
        }


    for(int i=0;i<=vx;i++)//节点初始化
    {
        used[i]=0;
        d[i]=INF;
        from[i]=0;
    }
}



void dijkstra(int s)//O(V^2)
{
    d[s]=0;//径长
    from[s]=s;//来源节点

    while(1)
    {
        int v=-1;
        for(int i=1;i<=vx;i++)//选择没有使用过，且距离最小点
            if(!used[i] && (v==-1 || d[i]<d[v]))
                v=i;

        if(v==-1)break;//所有点都使用过
        used[v]=1;

        for(int i=1;i<=vx;i++)//遍历所有与之相连的点
            if(d[v]+cost[v][i] < d[i])
            {
                d[i]=d[v]+cost[v][i];//更新权值
                from[i]=v;//更新来源节点
            }
    }
}

QString getPath_1(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);

    if(ve!=ori)return getPath_2(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_2(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);


    if(ve!=ori)return getPath_3(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_3(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);


    if(ve!=ori)return getPath_4(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_4(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);


    if(ve!=ori)return getPath_5(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_5(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);


    if(ve!=ori)return getPath_6(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_6(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);


    if(ve!=ori)return getPath_7(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_7(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);

    if(ve!=ori)return getPath_8(from[ve])+QString(",V")+QString(s);
    if(ve==ori)return QString("V")+QString(s);
    return QString();
}
QString getPath_8(int ve)//获得路径
{

    char s[100];
    sprintf(s,"%d",ve);

    if(ve==ori)return QString("V")+QString(s);
    return QString("sss");
}

void culc()
{
    dataInit();

    dijkstra(ori);

//    for(i=1;i<=vx;i++)//输出结果
//    {
//        printf("V%d: ",i);
//        getPath(i);
//        printf("\n");
//        printf("cost: %d\n\n",d[i]);
//    }

//    for(i=1;i<=vx;i++)
//    {
//        path[i]=getPath(i);
//    }
}


#endif // DIJKSTRA_H
