#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dijkstra.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_radioButton_4_clicked()
{

}


void MainWindow::on_spinBox1_2_valueChanged(int arg1)
{
    ui->spinBox2_1->setValue(arg1);
}
void MainWindow::on_spinBox1_3_valueChanged(int arg1)
{
    ui->spinBox3_1->setValue(arg1);
}
void MainWindow::on_spinBox1_4_valueChanged(int arg1)
{
    ui->spinBox4_1->setValue(arg1);
}
void MainWindow::on_spinBox1_5_valueChanged(int arg1)
{
    ui->spinBox5_1->setValue(arg1);
}
void MainWindow::on_spinBox1_6_valueChanged(int arg1)
{
    ui->spinBox6_1->setValue(arg1);
}
void MainWindow::on_spinBox1_7_valueChanged(int arg1)
{
    ui->spinBox7_1->setValue(arg1);
}
void MainWindow::on_spinBox1_8_valueChanged(int arg1)
{
    ui->spinBox8_1->setValue(arg1);
}
void MainWindow::on_spinBox1_9_valueChanged(int arg1)
{
    ui->spinBox9_1->setValue(arg1);
}
void MainWindow::on_spinBox1_10_valueChanged(int arg1)
{
    ui->spinBox10_1->setValue(arg1);
}


void MainWindow::on_spinBox2_3_valueChanged(int arg1)
{
    ui->spinBox3_2->setValue(arg1);
}
void MainWindow::on_spinBox2_4_valueChanged(int arg1)
{
    ui->spinBox4_2->setValue(arg1);
}
void MainWindow::on_spinBox2_5_valueChanged(int arg1)
{
    ui->spinBox5_2->setValue(arg1);
}
void MainWindow::on_spinBox2_6_valueChanged(int arg1)
{
    ui->spinBox6_2->setValue(arg1);
}
void MainWindow::on_spinBox2_7_valueChanged(int arg1)
{
    ui->spinBox7_2->setValue(arg1);
}
void MainWindow::on_spinBox2_8_valueChanged(int arg1)
{
    ui->spinBox8_2->setValue(arg1);
}
void MainWindow::on_spinBox2_9_valueChanged(int arg1)
{
    ui->spinBox9_2->setValue(arg1);
}
void MainWindow::on_spinBox2_10_valueChanged(int arg1)
{
    ui->spinBox10_2->setValue(arg1);
}


void MainWindow::on_spinBox3_4_valueChanged(int arg1)
{
    ui->spinBox4_3->setValue(arg1);
}
void MainWindow::on_spinBox3_5_valueChanged(int arg1)
{
    ui->spinBox5_3->setValue(arg1);
}
void MainWindow::on_spinBox3_6_valueChanged(int arg1)
{
    ui->spinBox6_3->setValue(arg1);
}
void MainWindow::on_spinBox3_7_valueChanged(int arg1)
{
    ui->spinBox7_3->setValue(arg1);
}
void MainWindow::on_spinBox3_8_valueChanged(int arg1)
{
    ui->spinBox8_3->setValue(arg1);
}
void MainWindow::on_spinBox3_9_valueChanged(int arg1)
{
    ui->spinBox9_3->setValue(arg1);
}
void MainWindow::on_spinBox3_10_valueChanged(int arg1)
{
    ui->spinBox10_3->setValue(arg1);
}

void MainWindow::on_spinBox4_5_valueChanged(int arg1)
{
    ui->spinBox5_4->setValue(arg1);
}
void MainWindow::on_spinBox4_6_valueChanged(int arg1)
{
    ui->spinBox6_4->setValue(arg1);
}
void MainWindow::on_spinBox4_7_valueChanged(int arg1)
{
    ui->spinBox7_4->setValue(arg1);
}
void MainWindow::on_spinBox4_8_valueChanged(int arg1)
{
    ui->spinBox8_4->setValue(arg1);
}
void MainWindow::on_spinBox4_9_valueChanged(int arg1)
{
    ui->spinBox9_4->setValue(arg1);
}
void MainWindow::on_spinBox4_10_valueChanged(int arg1)
{
    ui->spinBox10_4->setValue(arg1);
}

void MainWindow::on_spinBox5_6_valueChanged(int arg1)
{
    ui->spinBox6_5->setValue(arg1);
}
void MainWindow::on_spinBox5_7_valueChanged(int arg1)
{
    ui->spinBox7_5->setValue(arg1);
}
void MainWindow::on_spinBox5_8_valueChanged(int arg1)
{
    ui->spinBox8_5->setValue(arg1);
}
void MainWindow::on_spinBox5_9_valueChanged(int arg1)
{
    ui->spinBox9_5->setValue(arg1);
}
void MainWindow::on_spinBox5_10_valueChanged(int arg1)
{
    ui->spinBox10_5->setValue(arg1);
}

void MainWindow::on_spinBox6_7_valueChanged(int arg1)
{
    ui->spinBox7_6->setValue(arg1);
}
void MainWindow::on_spinBox6_8_valueChanged(int arg1)
{
    ui->spinBox8_6->setValue(arg1);
}
void MainWindow::on_spinBox6_9_valueChanged(int arg1)
{
    ui->spinBox9_6->setValue(arg1);
}
void MainWindow::on_spinBox6_10_valueChanged(int arg1)
{
    ui->spinBox10_6->setValue(arg1);
}

void MainWindow::on_spinBox7_8_valueChanged(int arg1)
{
    ui->spinBox8_7->setValue(arg1);
}
void MainWindow::on_spinBox7_9_valueChanged(int arg1)
{
    ui->spinBox9_7->setValue(arg1);
}
void MainWindow::on_spinBox7_10_valueChanged(int arg1)
{
    ui->spinBox10_7->setValue(arg1);
}


void MainWindow::on_spinBox8_9_valueChanged(int arg1)
{
    ui->spinBox9_8->setValue(arg1);
}
void MainWindow::on_spinBox8_10_valueChanged(int arg1)
{
    ui->spinBox10_8->setValue(arg1);
}

void MainWindow::on_spinBox9_10_valueChanged(int arg1)
{
    ui->spinBox10_9->setValue(arg1);
}

void MainWindow::on_pushButton_clicked()
{

    ui->label_tag->setText("开始执行...");

//        /*获取边的权值*/
        cost[1][2]=ui->spinBox1_2->value();
        cost[1][3]=ui->spinBox1_3->value();
        cost[1][4]=ui->spinBox1_4->value();
        cost[1][5]=ui->spinBox1_5->value();
        cost[1][6]=ui->spinBox1_6->value();
        cost[1][7]=ui->spinBox1_7->value();
        cost[1][8]=ui->spinBox1_8->value();
        cost[1][9]=ui->spinBox1_9->value();
        cost[1][10]=ui->spinBox1_10->value();

        cost[2][3]=ui->spinBox2_3->value();
        cost[2][4]=ui->spinBox2_4->value();
        cost[2][5]=ui->spinBox2_5->value();
        cost[2][6]=ui->spinBox2_6->value();
        cost[2][7]=ui->spinBox2_7->value();
        cost[2][8]=ui->spinBox2_8->value();
        cost[2][9]=ui->spinBox2_9->value();
        cost[2][10]=ui->spinBox2_10->value();

        cost[3][4]=ui->spinBox3_4->value();
        cost[3][5]=ui->spinBox3_5->value();
        cost[3][6]=ui->spinBox3_6->value();
        cost[3][7]=ui->spinBox3_7->value();
        cost[3][8]=ui->spinBox3_8->value();
        cost[3][9]=ui->spinBox3_9->value();
        cost[3][10]=ui->spinBox3_10->value();

        cost[4][5]=ui->spinBox4_5->value();
        cost[4][6]=ui->spinBox4_6->value();
        cost[4][7]=ui->spinBox4_7->value();
        cost[4][8]=ui->spinBox4_8->value();
        cost[4][9]=ui->spinBox4_9->value();
        cost[4][10]=ui->spinBox4_10->value();

        cost[5][6]=ui->spinBox5_6->value();
        cost[5][7]=ui->spinBox5_7->value();
        cost[5][8]=ui->spinBox5_8->value();
        cost[5][9]=ui->spinBox5_9->value();
        cost[5][10]=ui->spinBox5_10->value();

        cost[6][7]=ui->spinBox6_7->value();
        cost[6][8]=ui->spinBox6_8->value();
        cost[6][9]=ui->spinBox6_9->value();
        cost[6][10]=ui->spinBox6_10->value();

        cost[7][8]=ui->spinBox7_8->value();
        cost[7][9]=ui->spinBox7_9->value();
        cost[7][10]=ui->spinBox7_10->value();

        cost[8][9]=ui->spinBox8_9->value();
        cost[8][10]=ui->spinBox8_10->value();

        cost[9][10]=ui->spinBox9_10->value();

        culc();//执行算法

        ui->label_tag->setText("执行完成.");


        ui->label_path_V_1->setText("{"+getPath_1(1)+"}");
        ui->label_path_V_2->setText("{"+getPath_1(2)+"}");
        ui->label_path_V_3->setText("{"+getPath_1(3)+"}");
        ui->label_path_V_4->setText("{"+getPath_1(4)+"}");
        ui->label_path_V_5->setText("{"+getPath_1(5)+"}");
        ui->label_path_V_6->setText("{"+getPath_1(6)+"}");
        ui->label_path_V_7->setText("{"+getPath_1(7)+"}");




        //径长显示
        ui->label_dis_V_1->setText(QString::number(d[1]));
        ui->label_dis_V_2->setText(QString::number(d[2]));
        ui->label_dis_V_3->setText(QString::number(d[3]));
        ui->label_dis_V_4->setText(QString::number(d[4]));
        ui->label_dis_V_5->setText(QString::number(d[5]));
        ui->label_dis_V_6->setText(QString::number(d[6]));
        ui->label_dis_V_7->setText(QString::number(d[7]));
//        ui->label_dis_V_8->setText(QString::number(d[8]));
//        ui->label_dis_V_9->setText(QString::number(d[9]));
//        ui->label_dis_V_10->setText(QString::number(d[10]));





}
